# Cardápio Digital – Casa do Tambaqui

Projeto composto por:
- `index.html`: cardápio digital e fluxo demonstrativo de pedidos.
- `qr.html`: gerador de QR Codes por número de mesa.

## Publicar com GitHub Pages

1. Crie um repositório público chamado `cardapio-digital` no GitHub.
2. Envie os arquivos `index.html` e `qr.html` para a raiz do repositório.
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, selecione **Deploy from a branch**.
5. Escolha a branch `main` e a pasta `/ (root)`, depois salve.
6. Aguarde a publicação. O endereço normalmente será:
   `https://SEU-USUARIO.github.io/cardapio-digital/`

## Configurar os QR Codes

Abra `qr.html` já publicado e substitua o endereço no campo **Link do cardápio**
pelo endereço real do seu GitHub Pages. Depois escolha o número da mesa e gere
o QR Code.

## Observação importante

Esta versão é demonstrativa: os cadastros, pedidos e pagamentos ficam apenas
na memória do navegador durante a sessão. Não há banco de dados nem integração
com pagamento real. Para uso real no restaurante, será necessário conectar um
backend e um banco de dados.
